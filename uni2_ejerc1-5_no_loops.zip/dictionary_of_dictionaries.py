my_dict = {
    "person1": {"name": "Alice", "age": 25, "city": "New York"},
    "person2": {"name": "Bob", "age": 30, "city": "San Francisco"},
    "person3": {"name": "Charlie", "age": 35, "city": "Los Angeles"},
}

person1_name = my_dict["person1"]["name"]
person2_age = my_dict["person2"]["age"]
person3_city = my_dict["person3"]["city"]

print(person1_name)
print(person2_age)
print(person3_city)
